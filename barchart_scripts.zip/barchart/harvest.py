import argparse
import io
import json
import logging

from bs4 import BeautifulSoup
import pandas as pd
import requests
from requests import adapters
from requests.packages.urllib3.util import retry
import urllib.parse

import constants


def retry_session(
    session=None,
    retries=5,
    backoff_factor=1,
    status_forcelist=constants.STATUS_FORCELIST,
    allowed_methods=constants.ALLOWED_METHODS,
):
    """Retries a session for a given number of times in case of connection failure"""
    max_retries = retry.Retry(
        total=retries,
        read=retries,
        connect=retries,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
        allowed_methods=allowed_methods,
    )
    adapter = adapters.HTTPAdapter(max_retries=max_retries)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


def get_csrf_token(response, tag_attr, **find_filters):
    """Returns the CSRF token from the page response"""
    soup = BeautifulSoup(response.text, "html.parser")
    tag = soup.find(**find_filters)
    csrf_token = tag.attrs[tag_attr]
    logging.info(f"GET {response.url}, status: {response.status_code}, CSRF token: {csrf_token}")
    return csrf_token


def create_session(login_url, email, password):
    """Returns a logged-in session to be used for downloading data """
    session = retry_session(session=requests.Session())
    with session as s:
        s.headers.update({'User-Agent': 'Mozilla/5.0'})
        response = s.get(login_url)
        csrf_token = get_csrf_token(response, 'value', type='hidden')
        payload = {"email": email, "password": password, "_token": csrf_token}
        response = s.post(login_url, data=payload)
        logging.info(f"POST {login_url}, status: {response.status_code}")
        if response.url == login_url:
            raise Exception("Invalid Barchart credentials")
    return session


def get_historical_data_page(session, symbol):
    """Returns the historical data page for a given symbol"""
    url = constants.HISTORICAL_DATA_URL.format(base_url=constants.BASE_URL, symbol=symbol)
    response = session.get(url)
    logging.info(f"GET {url}, status {response.status_code}")
    if response.status_code != 200:
        raise Exception(f"No downloadable data found for symbol '{symbol}'")
    return response


def get_headers(url, xsrf_token):
    """Returns the headers to be used for downloading data"""
    return  dict(constants.HEADERS, **{
        "Referer": url,
        "x-xsrf-token": xsrf_token,
    })


def allowed_daily_download_response(session, page_url, page_cookies):
    """Returns the response for checking if the max daily download has been reached"""
    payload = {"onlyCheckPermissions": "true"}
    xsrf_token = urllib.parse.unquote(page_cookies['XSRF-TOKEN'])
    headers = get_headers(page_url, xsrf_token)
    response = session.post(constants.DATA_DOWNLOAD_URL, data=payload, headers=headers)
    return response


def allowed_daily_download_reached(response, status_code):
    """Returns True if the max daily download has been reached, False otherwise"""
    download_allowed = json.loads(response)
    if download_allowed['success']:
        logging.info(
            f"POST {constants.DATA_DOWNLOAD_URL}, "
            f"status: {status_code}, "
            f"allowance success: {download_allowed['success']}, "
            f"allowance count: {download_allowed['count']}"
        )
        return True
    return False


def get_download_payload(symbol, period, start_date, end_date, csrf_token):
    """Returns the payload to be used for downloading data"""
    payload = dict(
        constants.DATA_DOWNLOAD_PAYLOAD,
        **{
            "_token": csrf_token,
            "fileName": f"{symbol}_Daily_Historical+Data",
            "symbol": symbol,
            "startDate": start_date,
            "endDate": end_date,
        }
    )
    if period == "daily":
        payload["type"] = "eod"
        payload["period"] = "daily"
    return payload


def save_to_csv(historical_data, csv_file_path):
    """Saves the historical data to a CSV file"""
    io_stream = io.StringIO(historical_data)
    df = pd.read_csv(io_stream, skipfooter=1, engine='python')
    date_format = '%Y-%m-%d'  # Daily date format example: 2021-01-01
    df['Time'] = pd.to_datetime(df['Time'], format=date_format)
    df.set_index('Time', inplace=True)
    df.index = df.index.tz_localize(tz='US/Central').tz_convert('UTC')
    df = df.rename(columns={"Last": "Close"})
    logging.info(f"writing to: {csv_file_path}")
    df.to_csv(csv_file_path, date_format=date_format)

def harvest_prices(session, symbol, period, start_date, end_date, download_dir):
    """Downloads the historical data for a given symbol and saves it to a CSV file"""
    file_name = f"{symbol}_{period}_{start_date}_{end_date}.csv"
    full_path = f"{download_dir}/{file_name}"
    historical_response = get_historical_data_page(session, symbol)
    allowed_response = allowed_daily_download_response(session, historical_response.url, historical_response.cookies)
    if not allowed_daily_download_reached(allowed_response.text, allowed_response.status_code):
        logging.info("Max daily download reached, aborting")
        return
    csrf_token = get_csrf_token(historical_response, 'content', name='meta', attrs={'name': 'csrf-token'})
    xsrf_token = urllib.parse.unquote(allowed_response.cookies['XSRF-TOKEN'])
    headers = get_headers(historical_response.url, xsrf_token)
    payload = get_download_payload(symbol, period, start_date, end_date, csrf_token)
    response = session.post(constants.DATA_DOWNLOAD_URL, data=payload, headers=headers)
    logging.info(
        f"POST {constants.DATA_DOWNLOAD_URL}, "
        f"status: {response.status_code}, "
        f"data length: {len(response.content)}"
    )

    if response.status_code == 200:

        if 'Error retrieving data' not in response.text:
            save_to_csv(response.text, full_path)
        else:
            logging.info(f"Barchart data problem for '{file_name}', not writing")

def main(symbol, period, start_date, end_date, download_dir):
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s %(levelname)s %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S')
    session = create_session(
        constants.LOGIN_URL, 
        constants.LOGIN_CREDENTIALS["email"], 
        constants.LOGIN_CREDENTIALS["password"]
    )

    harvest_prices(session, symbol, period, start_date, end_date, download_dir)


if __name__ == "__main__":

    parser = argparse.ArgumentParser(
        description="Downloads historical data from Barchart.com."
    )
    parser.add_argument(
        "--symbol", type=str, required=True, help="Barchart symbol to download data e.g. SBY00."
    )
    parser.add_argument(
        "--period", choices=("daily"), type=str, required=True, help="Period to download data for e.g. daily."
    )
    parser.add_argument(
        "--start_date", type=str, required=True, help="Start date to download data for e.g. 2021-01-01."
    )
    parser.add_argument(
        "--end_date", type=str, required=True, help="End date to download data for e.g. 2023-12-31."
    )
    parser.add_argument(
        "--download_dir", type=str, required=True, help="Directory to save the downloaded data to."
    )
    args = parser.parse_args()
    main(args.symbol, args.period, args.start_date, args.end_date, args.download_dir)
