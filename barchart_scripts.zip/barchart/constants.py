from requests.packages.urllib3.util import retry


BASE_URL = "https://www.barchart.com"
LOGIN_URL = f"{BASE_URL}/login"
HISTORICAL_DATA_URL = "{base_url}/futures/quotes/{symbol}/historical-download"
DATA_DOWNLOAD_URL = f"{BASE_URL}/my/download"
LOGIN_CREDENTIALS = {"email": "nick@kwolco.com", "password": "Kulea1234!!"}
STATUS_FORCELIST = (404, 408, 429, 500, 502, 503, 504, 509)
ALLOWED_METHODS = retry.Retry.DEFAULT_ALLOWED_METHODS.union(["POST"])
HEADERS = {
    "content-type": "application/x-www-form-urlencoded",
    "Accept-Encoding": "gzip, deflate, br",
}
DATA_DOWNLOAD_PAYLOAD = {
    "fields": "tradeTime.format(Y-m-d),openPrice,highPrice,lowPrice,lastPrice," \
        "priceChange,percentChange,volume,openInterest",
    "orderBy": "tradeTime",
    "orderDir": "asc",
    "method": "historical",
    "limit": "10000",
    "customView": "true",
    "pageTitle": "Historical Data"
}
