# How to run it

Run the [run.py](run.py) script with the correct variables as listed out below

Example:

```shell
python c:/<path_to_harvets_script> \
    --symbol SBY00
    --period daily
    --start_date 2021-01-01
    --end_date 2023-10-16
    --download_dir c:/home/nkoech/Downloads
```
